import json
import boto3
import logging

# Initialise the SageMaker Runtime Client
sagemaker_runtime = boto3.clinet('sagemaker-runtime')

# Initialise the API Gateway Management API Client
apigateway_management = boto3.clinet('apigatewaymanagementapi', endpoint_url = 'https://example.com')

# Set up Logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    # Log the incoming event
    logger.info((f"Recieved event: {json.dumps(event)}"))

    # Extract the payload from the event
    payload = event.get('body', None)
    if not payload:
        logger.error("No data provided for inference.")
        return # Early exit if no input
    
    # Invoke the SageMaker Endpoint
    endpoint_name = "lstm-cloud-model"
    try:
        response = sagemaker_runtime.invoke_endpoint(
            EndpointName = endpoint_name,
            ContentType = 'application/json',
            Body = json.dumps(payload)
        )

        # Process the response
        result = json.loads(response['Body'].read())
        logger.info(f"Inference result: {result}")

        # Send alert to WebSocket API Gateway
        connection_id = "mock-connection-id"
        send_alert(connection_id, result)

    except Exception as e:
        logger.error(f"Error invoking Sagemaker endpoint: {e}")
        return
    
def send_alert(connection_id, message):
    try:
        apigateway_management.post_to_connection(
            ConnectionId = connection_id,
            Data = json.dumps(message)
        )
        logger.info(f"Alert sent to connection ID {connection_id}: {message}")

    except Exception as e:
        logger.error(f"Error sending alert to WebSocket: {e}")